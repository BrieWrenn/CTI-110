user_text = input()
count = 0
for ch in user_text:
    if ch == ' ' or ch == '.' or ch == ',' or ch == '!':
        count = count + 0
    else:
        count = count + 1
print(count)
